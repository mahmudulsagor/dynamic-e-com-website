
 <div class="box">
 	<?php
 	$session_email=$_SESSION['customer_email'];
 	$select_customer="select * from customers where customer_email='$session_email'";
 	$run_cust=mysqli_query($con,$select_customer);
 	$row_customer=mysqli_fetch_array($run_cust);
 	$customer_id=$row_customer['customer_id'];


 	?>

 	<center>
 	<h2 class="taxt-center">Payment options</h2>
 	<p class="lead text-center">
 		<a href="order.php?c_id=<?php echo $customer_id ?>">Pay Offline</a>
 		
 	</p>
 	</center>

 	<center>
 		<p class="lead">
 			<a href="#">Pay with paypal
 				<img src="images/paypal.png" width="200" height="120" class="img-responsive"></a>
 		</p>

 	</center>



 	<center>
 		<p class="lead">
 			<a href="#">Pay with BKash
 				<img src="images/BKash.png" width="200" height="120" class="img-responsive"></a>
 		</p>

</center>


 		<center>
 		<p class="lead">
 			<a href="#">Pay with Rocket
 				<img src="images/rocket.png" width="200" height="120" class="img-responsive"></a>
 		</p>

 	

 	</center>


<center>
 		<p class="lead">
 			<a href="#">Pay with Nagad
 				<img src="images/nogod.png" width="200" height="120" class="img-responsive"></a>
 		</p>

 	</center>
 	

<center>
 		<p class="lead">
 			<a href="#">Pay with Payoneer
 				<img src="images/Payoneer.png" width="200" height="120" class="img-responsive"></a>
 		</p>



 </div>