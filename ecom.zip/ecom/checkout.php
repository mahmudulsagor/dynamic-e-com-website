<?php
session_start();
include("includes/db.php");
?>

<?php
include("functions/functions.php");
?>



<!DOCTYPE html>
<html>
<head>
	<title>Dream Mart BD</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="styles/style.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">



</head>
<body>
		<div id="top"> <!--Top Bar Start-->
			<div class="container"> <!--container start-->

				<div class="col-md-6 offer"> <!--col-md-6, welcome guest btn start-->
					<a href="#" class="btn btn-success btn-sm">
						
						<?php
						if(!isset($_SESSION['customer_email'])){
							echo "Welcome guest";
						}else{
							echo "Welcome: " .$_SESSION['customer_email'] . "";
						}

						?>


					</a>
					<a href="#">Shopping card Total price:BDT <?php totalPrice(); ?>, <?php item(); ?>Total Items  </a>

				</div><!--col-md-6, welcome guest btn end-->


				<div><!--col-md-6, welcome guest btn start-->

					<div class="col-md-6">
						<ul class="menu">

							<li>
								<a href="customer_registration.php"> Register</a>
								

							</li>


							<li>

									<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>
								

							</li>

							<li>

								<a href="cart.php"> Goto Cart</a>

							</li>


							<li>

							<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>

						</li>





						</ul>




					</div>


				</div><!--col-md-6, welcome guest btn end-->



			</div><!--container finish-->


		</div><!--Top Bar end-->





		<div class="navbar navbar-default" id="navbar"><!--navbar default start-->
			<div class="container">
				<div class="navbar-header">
					<a class="navbar-brand home" href="index.php">
						<img src="images/logo lrg.png" alt="DMB Logo" class="hidden-xs">
						<img src="images/logo sml.png" alt="DMB Logo" class="visible-xs">


					</a>

					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation"><!--toggle start-->

						<span class="sr-only">Toggle Navigation	</span>

						<i class="fa fa-align-justify"></i>

						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search"><!--search start-->

							<span class="sr-only">	</span>
							<i class="fa fa-search"></i>

						</button><!--toggle end -->
						

					</button><!--search end-->





				</div><!--navbar header End-->

				<div class="navbar-collapse-collapse" id="navigation"><!--navbar-collapse-collapse start-->

					<div class="padding-nav"><!--Padding nav start-->
						<ul class="nav navbar-nav navbar-left">
							<li class="active">
								<a href="index.php">Home</a>

								<li>
									<a href="shop.php">Shop</a>
								</li>
								<li>
										<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>
								</li>
								<li>
									<a href="cart.php">Shoping Cart</a>
								</li>
								
								<li>
									<a href="contactus.php">Contact Us</a>
								</li>


							</li>

						</ul>


					</div><!--padding nav end-->

					<a href="cart.php" class="btn btn-primary navbar-btn right">
						<i class="fa fa-shopping-cart"></i>
						<span> <?php item(); ?>Iems in cart</span>
					</a>

					<div class="navbar-collapse collapse-right"><!--navbar-collapse collapse-right start-->
						<button class="btn navbar-btn btn-primary" type="button" data-toggle="collapse" data-target="#search">
							<span class="sr-only">Toggle Search</span>
								
							
							<i class="fa fa-search"> </i>
							
						</button>
						


					</div><!--navbar-collapse collapse-right end-->

					<div class="collapse clearfix" id="search">
						<form class="navbar-form" method="get" action="result.php">
							<div class="input-group">

		<input type="text" name="user_query" placeholder="search" class="form-control" required="">

				<span class="input-group-btn">

				<button type="submit" value="search" name="search" class="btn btn-primary">
									<i class="fa fa-search"></i>
									
								</button>
								
								</span>

							</div>
							
						</form>
						



					</div>
					


				</div><!--navbar-collapse-collapse End-->

			</div><!--navbar container End-->




		</div><!--navbar default End-->


		<div id="content">
			<div class="container"><!--container start-->
				<div class="col-md-12"><!--col-md-12 start-->
					<ul class="breadcrumb">
						<li><a href="home.php">Home</a></li>
						<li>Checkout</li>
						


					</ul>
					


				</div><!--col-md-12 end-->

				 <div class="col-md-3"><!--col-md-3 start-->
				 	<?php
				 	include("includes/sidebar.php");
				 	?>

				 </div><!--col-md-3 end-->




<div class="col-md-9"><!--col-md-9 start-->
	<?php
	if (!isset($_SESSION['customer_email'])) {
		include('customers/customer_login.php');

		
	}else{

		include('payment_options.php');
	}

	?>
	


</div><!--col-md-9 end-->





















	</div><!--container end-->

		</div>





<!--Footer start-->

<?php
include("includes/footer.php")


?>

<!--Footer end-->
