<?php
session_start();
include("includes/db.php");
include("functions/functions.php"); 

?>
<?php

if (isset($_GET['pro_id'])) {
	$pro_id=$_GET['pro_id'];
	$get_product="select * from products where product_id='$pro_id'";
	$run_product=mysqli_query($con,$get_product);
	$row_product=mysqli_fetch_array($run_product);
	$p_cat_id=$row_product['p_cat_id'];
	$p_title=$row_product['product_title'];
	$p_price=$row_product['product_price'];
	$p_desc=$row_product['product_desc'];
	$p_img1=$row_product['product_img1'];
	$p_img2=$row_product['product_img2'];
	$p_img3=$row_product['product_img3'];
	$get_p_cat="select * from product_categories where p_cat_id='$p_cat_id'";
	$run_p_cat=mysqli_query($con,$get_p_cat);
	$row_p_cat=mysqli_fetch_array($run_p_cat);
	$p_cat_id=$row_p_cat['p_cat_id'];
	$p_cat_title=$row_p_cat['p_cat_title'];



}




?>


<!DOCTYPE html>
<html>
<head>
	<title>Dream Mart BD</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="styles/style.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">



</head>
<body>
		<div id="top"> <!--Top Bar Start-->
			<div class="container"> <!--container start-->

				<div class="col-md-6 offer"> <!--col-md-6, welcome guest btn start-->
					<a href="#" class="btn btn-success btn-sm">


						<?php
						if(!isset($_SESSION['customer_email'])){
							echo "Welcome guest";
						}else{
							echo "Welcome: " .$_SESSION['customer_email'] . "";
						}

						?>



					</a>
					<a href="#">Shopping card Total price:BDT <?php totalPrice(); ?>, Total Items <?php item(); ?> </a>

				</div><!--col-md-6, welcome guest btn end-->


				<div><!--col-md-6, welcome guest btn start-->

					<div class="col-md-6">
						<ul class="menu">

							<li>
								<a href="customer_registration.php"> Register</a>
								

							</li>


							<li>

									<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>
								

							</li>

							<li>

								<a href="cart.php"> Goto Cart</a>

							</li>


							<li>

							<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>

						</li>





						</ul>




					</div>


				</div><!--col-md-6, welcome guest btn end-->



			</div><!--container finish-->


		</div><!--Top Bar end-->





		<div class="navbar navbar-default" id="navbar"><!--navbar default start-->
			<div class="container">
				<div class="navbar-header">
					<a class="navbar-brand home" href="index.php">
						<img src="images/logo lrg.png" alt="DMB Logo" class="hidden-xs">
						<img src="images/logo sml.png" alt="DMB Logo" class="visible-xs">


					</a>

					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation"><!--toggle start-->

						<span class="sr-only">Toggle Navigation	</span>

						<i class="fa fa-align-justify"></i>

						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search"><!--search start-->

							<span class="sr-only">	</span>
							<i class="fa fa-search"></i>

						</button><!--toggle end -->
						

					</button><!--search end-->





				</div><!--navbar header End-->

				<div class="navbar-collapse-collapse" id="navigation"><!--navbar-collapse-collapse start-->

					<div class="padding-nav"><!--Padding nav start-->
						<ul class="nav navbar-nav navbar-left">
							<li>
								<a href="index.php">Home</a>

								<li class="active">
									<a href="shop.php">Shop</a>
								</li>
								<li><?php
								if (!isset($_SESSION['customer_email'])) {
									echo "<a href='checkout.php'>My Account</a>";
								}else{
									echo "<a href='customers/my_account.php?my_order'>My Account </a>";
								}

								?>
								</li>
								<li>
									<a href="cart.php">Shoping Cart</a>
								</li>
								
								<li>
									<a href="contactus.php">Contact Us</a>
								</li>


							</li>

						</ul>


					</div><!--padding nav end-->

					<a href="cart.php" class="btn btn-primary navbar-btn right">
						<i class="fa fa-shopping-cart"></i>
						<span><?php item(); ?>Items in cart</span>
					</a>

					<div class="navbar-collapse collapse-right"><!--navbar-collapse collapse-right start-->
						<button class="btn navbar-btn btn-primary" type="button" data-toggle="collapse" data-target="#search">
							<span class="sr-only">Toggle Search</span>
								
							
							<i class="fa fa-search"> </i>
							
						</button>
						


					</div><!--navbar-collapse collapse-right end-->

					<div class="collapse clearfix" id="search">
						<form class="navbar-form" method="get" action="result.php">
							<div class="input-group">

		<input type="text" name="user_query" placeholder="search" class="form-control" required="">

				<span class="input-group-btn">

				<button type="submit" value="search" name="search" class="btn btn-primary">
									<i class="fa fa-search"></i>
									
								</button>
								
								</span>

							</div>
							
						</form>
						



					</div>
					


				</div><!--navbar-collapse-collapse End-->

			</div><!--navbar container End-->




		</div><!--navbar default End-->


		<div id="content">
			<div class="container"><!--container start-->
				<div class="col-md-12"><!--col-md-12 start-->
					<ul class="breadcrumb">
						<li><a href="home.php">Home</a></li>
						<li>Shop</li>

						<li><a href="shop.php?p_cat=<?php echo $p_cat_id;?>"><?php echo $p_cat_title ?></a></li>
							

							<li><?php echo $p_title ?></li>
						


					</ul>
					


				</div><!--col-md-12 end-->

				 <div class="col-md-3"><!--col-md-3 start-->
				 	<?php
				 	include("includes/sidebar.php");
				 	?>

				 </div><!--col-md-3 end-->


				 <div class="col-md-9">
				 	<div class="row" id="productmain"><!--row start-->

				 		<div class="col-sm-6"><!--col-sm-6 slider start-->
				 			<div id="mainimage">

				 				<div id="mycarousel slide" data-ride="carousel">
				 					<ol class="carousel-indecators">
				 						<li data-target="#mycarousel" data-slide-to="0" class="active"></li>
				 						<li data-target="#mycarousel" data-slide-to="1"></li>
				 						<li data-target="#mycarousel" data-slide-to="2"></li>
				 						

				 					</ol>


				 					<div class="carousel-inner"><!--carousel-inner start-->
				 						<div class="item active">
				 							<center>
				 								
				 								<img src="admin_area/product_image/<?php echo $p_img1  ?>" class="img-responsive">
				 							</center>
				 							
				 						</div>

				 						<div class="item">
				 							<center>
				 								
				 								<img src="admin_area/product_image/<?php echo $p_img2  ?>" class="img-responsive">
				 							</center>
				 							
				 						</div>

				 						<div class="item">
				 							<center>
				 								
				 		<img src="admin_area/product_image/<?php echo $p_img3  ?>" class="img-responsive">
				 			</center>
				 							
				 		</div>

				 			
				 	</div><!--carousel-inner end-->

				 	<a href="#mycarousel" class="left carousel-control" data-slide="prev"></a>
				 	<span class="glyphicon glyphicon-chevron-left"></span>
				 	<span class="sr-only">Previous</span>
				 					

				 				<a href="#mycarousel" class="right carousel-control" data-slide="next"></a>
				 	<span class="glyphicon glyphicon-chevron-right"></span>
				 	<span class="sr-only">Next</span>
				 					


				 				</div>
				 				

				 			</div>
				 			

				 		</div><!--col-sm-6 slider end-->

				 		<div class="col-sm-6"><!--col-sm-6 slider start-->

				 		<div class="box"><!--box start-->

				 		<h1 class="text-center"><?php echo $p_title?></h1>
				 		
				 		<?php 
				 		addCart();

				 		?>

				 		<form action="details.php?add_cart=<?php echo $pro_id  ?>" method="post" class="form-horizontal"><!--form start-->

				 		<div class="form-group"><!--form-group start-->

				 		<label class="col-md-5 control-label">Product Quantity</label>

				 		<div class="col-md-7"><!--col-md-7 start-->

				 		<select name="product_qty" class="form-control">
				 			<option>1</option>
				 			<option>2</option>
				 			<option>3</option>
				 			<option>4</option>
				 			<option>5</option>
				 			<option>10</option>
				 			<option>50</option>
				 			<option>100</option>


				 		</select>
				 			

				 		</div><!--col-md-7 end-->
				 			

				 		</div><!--form-group end-->

				 		<div class="form-group"><!--form-group start-->
				 			
				 			<label class="col-md-5 control-label">Product Size</label>

				 			<div class="col-md-7">
				 				<select name="product_size" class="form-control">
				 				<option>Select Size</option>
				 				<option>M</option>
				 				<option>L</option>
				 				<option>XL</option>
				 				<option>XXL</option>
				 				<option>S</option>
				 				
				 				



				 				</select>
				 				
				 			</div>

				 		</div><!--form-group end-->
				 			
				 		<p class="price">BDT<?php echo $p_price; ?></p>
				 		<p class="text-center buttons"><p/>
				 		<button class="btn btn-primary" type="submit">
				 		<i class="fa fa-shopping-cart">Add to cart</i>

				 		</button>


				 		</form><!--form end-->
				 			

				 		</div><!--box end-->
				 			

				 			<div class="col-xs-4"><!--col-xs-4 start-->

				 				<a href="#" class="thumb">
				 				<img src="admin_area/product_image/<?php echo $p_img1 ?>" class="img-responsive">  
				 				</a>
				 				

				 			</div><!--col-xs-4 end-->


				 			<div class="col-xs-4"><!--col-xs-4 start-->

				 				<a href="#" class="thumb">
				 				<img src="admin_area/product_image/<?php echo $p_img2 ?>" class="img-responsive">  
				 				</a>
				 				

				 			</div><!--col-xs-4 end-->


				 			<div class="col-xs-4"><!--col-xs-4 start-->

				 				<a href="#" class="thumb">
				 				<img src="admin_area/product_image/<?php echo $p_img3 ?>" class="img-responsive">  
				 				</a>
				 				

				 			</div><!--col-xs-4 end-->



				 		</div><!--col-sm-6 slider end-->

				 		
				 	</div><!--row end-->

				 	<div class="box">

				 	<div class="box" id="details"><!--product details box start-->

				 	<h4>Products Details</h4>
				 	<p>
                            <?php echo $p_desc ?>

                              </p>


				            <h4>Size</h4>

				            <ul>

				             <li>M</li>
				             <li>L</li>
				             <li>XL</li>
				             <li>XXL</li>
				             <li>S</li>
				 	
				             </ul>
				 		
				 	</div><!--product details box end-->

				 	</div>

				 	<div class="row same-height-row"><!--row same-height-row start-->

				 	<div class="col-md-3 col-sm-6"><!--col-md-3 col-sm-6 start-->


				 		<div class="box same-height headline"><!--box same-height headline start-->

				 			<h3 class="text-center">Yo Also Like These Products</h3>
				 			

				 		</div><!--box same-height headline end-->
				 		

				 	</div><!--col-md-3 col-sm-6 end-->

				 	<?php
				 	$get_product="select * from products order by 1 LIMIT 0,3";
				 	$run_product=mysqli_query($con,$get_product);
				 	while ($row=mysqli_fetch_array($run_product)) {
				 		$pro_id=$row['product_id'];
				 		$product_title=$row['product_title'];
				 		$product_price=$row['product_price'];
				 		$product_img1=$row['product_img1'];
				 		echo "
				 		<div class='center-responsive col-md-3 col-sm-6'>
				 		<div class='product same-height'>
				 		<a href='details.php?pro_id=$pro_id'>
				 		<img src='admin_area/product_image/$product_img1' class='img-responsive'>

				 		</a>
				 		<div class='text'>

				 		<h3> <a href='details.php?pro_id=$pro_id'>$product_title</a> </h3>
				 		<p class='price'>$product_price</p>

				 		</div>

				 		</div>


				 		</div>



				 		";


				 	}



				 	?>
				 		

				 	</div><!--row same-height-row end-->
				 	

				 </div>









				 </div><!--container end-->

		</div><!--content end-->












<!--Footer start-->

<?php
include("includes/footer.php")


?>

<!--Footer end-->

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>










</body>
</html>