<?php
session_start();
if (!isset($_SESSION['customer_email'])) {
	echo "<script>window.open('../checkout.php','_self')</script>";

}else{


include("includes/db.php");
include("functions/functions.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>Dream Mart BD</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="styles/style.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">



</head>
<body>
		<div id="top"> <!--Top Bar Start-->
			<div class="container"> <!--container start-->

				<div class="col-md-6 offer"> <!--col-md-6, welcome guest btn start-->
					<a href="#" class="btn btn-success btn-sm">

						<?php
						if(!isset($_SESSION['customer_email'])){
							echo "Welcome guest";
						}else{
							echo "Welcome: " .$_SESSION['customer_email'] . "";
						}

						?>

						
					</a>

					
				</div><!--col-md-6, welcome guest btn end-->


				<div><!--col-md-6, welcome guest btn start-->

					<div class="col-md-6">
						<ul class="menu">

							<li>
								<a href="../customer_registration.php"> Register</a>
								

							</li>


							<li>

									<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>

							</li>

							<li>

								<a href="../cart.php"> Goto Cart</a>

							</li>


							<li>

							
								<?php
							if (!isset($_SESSION['customer_email'])) {
								echo "<a href='checkout.php'>Login</a>";
							}else{
								echo "<a href='logout.php'>Logout</a>";
							}

							?>


						</li>





						</ul>




					</div>


				</div><!--col-md-6, welcome guest btn end-->



			</div><!--container finish-->


		</div><!--Top Bar end-->





		<div class="navbar navbar-default" id="navbar"><!--navbar default start-->
			<div class="container">
				<div class="navbar-header">
					<a class="navbar-brand home" href="../index.php">
						<img src="images/logo lrg.png" alt="DMB Logo" class="hidden-xs">
						<img src="images/logo sml.png" alt="DMB Logo" class="visible-xs">


					</a>

					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation"><!--toggle start-->

						<span class="sr-only">Toggle Navigation	</span>

						<i class="fa fa-align-justify"></i>

						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search"><!--search start-->

							<span class="sr-only">	</span>
							<i class="fa fa-search"></i>

						</button><!--toggle end -->
						

					</button><!--search end-->





				</div><!--navbar header End-->

				<div class="navbar-collapse-collapse" id="navigation"><!--navbar-collapse-collapse start-->

					<div class="padding-nav"><!--Padding nav start-->
						<ul class="nav navbar-nav navbar-left">
							<li>
								<a href="../index.php">Home</a>

								<li>
									<a href="../shop.php">Shop</a>
								</li>
								<li class="active">
									<?php
								if (!isset($_SESSION['customer_email'])) {
									echo "<a href='checkout.php'>My Account</a>";
								}else{
									echo "<a href='customers/my_account.php?my_order'>My Account </a>";
								}

								?>
								</li>
								<li>
									<a href="../cart.php">Shoping Cart</a>
								</li>
								
								<li>
									<a href="../contactus.php">Contact Us</a>
								</li>


							</li>

						</ul>


					</div><!--padding nav end-->

					<a href="cart.php" class="btn btn-primary navbar-btn right">
						<i class="fa fa-shopping-cart"></i>
						<span> Item in cart</span>
					</a>

					<div class="navbar-collapse collapse-right"><!--navbar-collapse collapse-right start-->
						<button class="btn navbar-btn btn-primary" type="button" data-toggle="collapse" data-target="#search">
							<span class="sr-only">Toggle Search</span>
								
							
							<i class="fa fa-search"> </i>
							
						</button>
						


					</div><!--navbar-collapse collapse-right end-->

					<div class="collapse clearfix" id="search">
						<form class="navbar-form" method="get" action="result.php">
							<div class="input-group">

		<input type="text" name="user_query" placeholder="search" class="form-control" required="">

				<span class="input-group-btn">

				<button type="submit" value="search" name="search" class="btn btn-primary">
									<i class="fa fa-search"></i>
									
								</button>
								
								</span>

							</div>
							
						</form>
						



					</div>
					


				</div><!--navbar-collapse-collapse End-->

			</div><!--navbar container End-->




		</div><!--navbar default End-->


		<div id="content">
			<div class="container"><!--container start-->
				<div class="col-md-12"><!--col-md-12 start-->
					<ul class="breadcrumb">
						<li><a href="home.php">Home</a></li>
						
						<li>My Account</li>
						


					</ul>
					


				</div><!--col-md-12 end-->

				 <div class="col-md-3"><!--col-md-3 start-->
				 	<?php
				 	include("includes/sidebar.php");
				 	?>

				 </div><!--col-md-3 end-->


<div class="col-md-9"><!--including my order.php page start-->

	<?php
	if(isset($_GET['my_order'])){
	include("my_order.php");
}
	?>
	
<!--including my order.php page end-->



	<!--including payoffline.php page start-->


				<?php
				if(isset($_GET['pay_offline'])){
				include("pay_offline.php");
			}
				?>


	<!--including payoffline.php page end-->


	<!--including edit account.php page start-->


	          <?php
				if(isset($_GET['edit_act'])){
				include("edit_act.php");
			}
				?>



	<!--including edit account.php page end-->

	<!--including change_password.php page start-->


				<?php
				if(isset($_GET['change_pass'])){
				include("change_password.php");
			}
				?>



	<!--including change_password page end-->

<!--including delete_ac.php page start-->



				<?php
				if(isset($_GET['delete_ac'])){
				include("delete_ac.php");
			}
				?>



<!--including delete_ac.php page end-->





</div><!--including my order.php page end-->






















				 				 </div><!--container end-->

		</div><!--content end-->












<!--Footer start-->

<?php
include("includes/footer.php")


?>

<!--Footer end-->

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>










</body>
</html>


<?php  } ?>