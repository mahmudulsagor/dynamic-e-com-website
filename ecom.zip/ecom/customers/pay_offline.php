<div class="box"><!--box start-->

	<center>
		<h1>Pay Offline Using below Method</h1>
		<p>If you have any questions, please feel free to contact us, our customer service is working for you 24/7.

			<button class="btn btn-primary responsive">
			<a href="../contactus.php">Contact Us</a>
			</button>
		</p>




	</center>

	<hr>
	<div class="table-responsive"><!--tabele-responsive start-->
		<table class="table table-bordered table-hover table-striped">

			<thead>
				<tr>
					<th>Bank Account Details</th>
					<th>Bkash Number</th>
					<th>Roket Number</th>
					<th>Nagad Number</th>
					<th>Payooner Id</th>


				</tr>
			</thead>

			<tbody>
				
				<tr>
					
					<td>00100206839893</td>
					<td>01300507086</td>
					<td>01300507086</td>
					<td>01300507086</td>
					<td>xxxxxxxxxxxxxxxx</td>

				</tr>
			</tbody>
			
		</table>
		
	</div><!--tabele-responsive end-->
	
</div><!--box end-->