<?php
$customer_email=$_SESSION['customer_email'];
$get_customer="select * from customers where customer_email='$customer_email' ";
$run_cust=mysqli_query($con,$get_customer);
$row_cust=mysqli_fetch_array($run_cust);
$customer_id=$row_cust['customer_id'];
$customer_name=$row_cust['customer_name'];
$customer_email=$row_cust['customer_email'];
$customer_country=$row_cust['customer_country'];
$customer_city=$row_cust['customer_city'];
$customer_contact=$row_cust['customer_contact'];
$customer_image=$row_cust['customer_image'];

?>




<div class="box"><!--box start-->

	<center>

	<h1>Edit Your Account</h1>
	
	</center>
	<form action="" method="post">

	<div class="form-group"><!--form-group start-->
		<label>Customer Name</label>
		<input type="text" name="c_name" class="form-control" value="<?php echo $customer_name; ?>" required="">
		
	</div><!--form-group end-->

	<div class="form-group"><!--form-group start-->
		<label>Customer Email</label>
		<input type="text" name="c_email" class="form-control" value="<?php echo $customer_email; ?>" required="">
		
	</div><!--form-group end-->

	

	<div class="form-group"><!--form-group start-->
		<label>Customer Country</label>
		<input type="text" name="c_country" class="form-control" value="<?php echo $customer_country; ?>"  required="">
		
	</div><!--form-group end-->

	<div class="form-group"><!--form-group start-->
		<label>Customer City</label>
		<input type="text" name="c_city" class="form-control" value="<?php echo $customer_city; ?>"  required="">
		
	</div><!--form-group end-->

	<div class="form-group"><!--form-group start-->
		<label>Contact Number</label>
		<input type="text" name="c_contact" class="form-control" value="<?php echo $customer_contact; ?>"  required="">
		
	</div><!--form-group end-->



	<div class="form-group"><!--form-group start-->
		<label>Customer Image</label>
		<input type="file" name="c_image" class="form-control">

		<img src="customer_image/<?php echo $customer_image; ?>" class="img-responsive" height="100" width="100">

		<div class="text-center">
			
				<button class="btn btn-primary" name="update">
			Update Now
			

		</button>

		
		
	</div><!--form-group end-->
</form>



</div><!--box end-->

<?php 
if(isset($_POST['update'])){
	 $update_id=$customer_id;
	 $c_name=$_POST['c_name'];
	 $c_email=$_POST['c_email'];
	$c_country=$_POST['c_country'];
	 $c_city=$_POST['c_city'];
	 $c_contact=$_POST['c_contact'];
	 $c_image=$_FILES['c_image']['name'];
	 $c_image_tmp=$_FILES['c_image']['tmp_name'];

	 move_uploaded_file($c_image_tmp,"customer_image/$c_image");
	 $update_customer= "update customers set customer_name='$c_name',customer_email='$c_email',customer_country='$c_country',customer_city='$c_city',customer_contact='$c_contact',customer_image='$c_image' where customer_id='$update_id'";

	 $run_customer=mysqli_query($con,$update_customer);
	 if ($run_customer) {
		echo "<script>alert('Your details updated')</script>";
		echo "<script>window.open('my_account.php','_self')</script>";
	}



}




?>