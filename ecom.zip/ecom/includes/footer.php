<div id="footer"><!--footer start-->
	<div class="container">
	<div class="row">
		<div class="col-md-3 col-sm-6"><!--col-md-3 col-sm-6 start-->
			<h4>Pages</h4>
			<ul>
				<li><a href="cart.php">Shoping cart</a></li>
				<li><a href="contact.php">Contact us</a></li>
				<li><a href="shop.php">Shop</a></li>
				<li><a href="checkout.php">My Acount</a></li>
			</ul>
			<hr>
			<h4>User Section</h4>
			<ul>
				<li><a href="checkout.php">Login</a></li>
				<li><a href="customer_registration.php">Registration</a></li>
			</ul>
			<hr class="hidden-md hidden-lg hidden-sm">
		</div><!--col-md-3 col-sm-6 end-->
		<div class="col-md-3 col-sm-6"><!--col-md-3 col-sm-6 start-->
			<h4>Top Product Categories</h4>
			<ul>
				<li><a href="#"> Computer Accessories</a></li>
				<li><a href="#"> Drone</a></li>
				<li><a href="#"> Electronics Product</a></li>
				<li><a href="#"> Sound System</a></li>
				<li><a href="#"> Fashion</a></li>
			</ul>
			<hr class="hidden-md hidden-lg">
			

		</div><!--col-md-3 col-sm-6 end-->
		<div class="col-md-3 col-sm-6"><!--col-md-3 col-sm-6 start-->
			<h4>Where to find us</h4>
			<p>
				<strong>dreammartbd.com</strong>
				<br>Bickna
				<br>Jhalokathi Sadar
				<br>Jhalokathi
				<br>Barishal
				<br>Bangladesh
				<br>dreammartbd@yahoo.com
				<br>01300507086
			</p>
			<a href="contactus.php">Go to Contact us page</a>
			<hr class="hidden-md hidden-lg">
		</div><!--col-md-3 col-sm-6 end-->
		<div class="col-md-3 col-sm-6"><!--col-md-3 col-sm-6 start-->
			<h4>Get the news</h4>
			<p class="text-muted">
				Subscribe here for getting news of Dream Mart
				
			</p>
			<form action="" method="post">
				<div class="input-group">
					<input type="text" name="email" class="form-control">
					<span class="input-group-btn">
						<input type="submit" class="btn btn-success" value="subscribe">
					</span>
					
				</div>
				
			</form>
			<hr>
			<h4>Stay In Touch</h4>
			<p class="social">
				<a href="https://www.facebook.com/dreammartbd.bsl"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="mailto:dreammartbd@yahoo.com"><i class="fa fa-envelope"></i></a>

				
			</p>
			
		</div><!--col-md-3 col-sm-6 end-->
		
	</div>		

	</div>
	
</div><!--footer end-->

<div id="copyright"><!--copyright start-->
	<div class="container"><!--container start-->
		<div class="col-md-6">
			<p class="pull-left">
				&copy; 2020 Mahmudul Sagor
				
			</p>
			

		</div>
		<div class="col-md-6">
			<p class="pull-right">
				Tamplate By: <a href="www.dreammartbd.com">Dream Mart BD</a>
				
			</p>
			
		</div>
		
	</div><!--container end-->
	
</div><!--copyright start-->