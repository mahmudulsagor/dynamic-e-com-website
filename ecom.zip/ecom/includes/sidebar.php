

<div class="panel panel-default sidebar-manu"><!--panel panel-default sidebar-manu start-->
	<div class="panel-heading">
		<h3 class="panel-title">Product categories</h3><!--panel-title start-->
		

	</div><!--panel-title end-->
	
<div class="panel-body">

	<ul class="nav nav-pills nav-stacked category-menu">

		<?php

	getPCats()

	?>



	</ul>
	

</div>


</div><!--panel panel-default sidebar-manu end-->





<div class="panel panel-default sidebar-manu"><!--panel panel-default sidebar-manu start-->
	<div class="panel-heading">
		<h3 class="panel-title"> categories</h3><!--panel-title start-->
		

	</div><!--panel-title end-->
	
<div class="panel-body">

	<ul class="nav nav-pills nav-stacked category-menu">
		
		<?php

		getCat()

		?>
		



	</ul>
	

</div>


</div><!--panel panel-default sidebar-manu end-->